"""
Drone Change Detection — CLI Entry Point
========================================
Usage:
    python main.py \
        --before-video  before.mp4 \
        --after-video   after.mp4 \
        --before-gps    before_gps.csv \
        --after-gps     after_gps.csv \
        --model         path/to/yolov8n_trained_by_me.pt \
        --output        output/ \
        [--gps-tolerance 5.0] \
        [--change-threshold 0.15] \
        [--yolo-conf 0.25] \
        [--no-homography] \
        [--no-save-frames]
"""

import argparse
import sys
import logging
from pathlib import Path

from change_detector import DroneChangeDetector, DetectionConfig

logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser(
        description="Drone shot change detection using GPS-aligned frame comparison + YOLOv8"
    )

    # Required
    p.add_argument("--before-video", required=True, help="Path to the BEFORE drone video")
    p.add_argument("--after-video", required=True, help="Path to the AFTER drone video")
    p.add_argument("--before-gps", required=True, help="CSV with GPS for before video")
    p.add_argument("--after-gps", required=True, help="CSV with GPS for after video")

    # Optional
    p.add_argument("--model", default="yolov8n_trained_by_me.pt",
                   help="Path to YOLOv8 .pt model (default: yolov8n_trained_by_me.pt)")
    p.add_argument("--output", default="output",
                   help="Output directory (default: output/)")
    p.add_argument("--gps-tolerance", type=float, default=5.0,
                   help="GPS match radius in metres (default: 5.0)")
    p.add_argument("--change-threshold", type=float, default=0.2,
                   help="Minimum change score 0-1 to flag an event (default: 0.15)")
    p.add_argument("--pixel-diff", type=int, default=100,
                   help="Per-pixel diff threshold 0-255 (default: 30)")
    p.add_argument("--min-change-pct", type=float, default=5.0,
                   help="Minimum %% pixels changed to consider (default: 2.0)")
    p.add_argument("--yolo-conf", type=float, default=0.25,
                   help="YOLO confidence threshold (default: 0.25)")
    p.add_argument("--yolo-iou", type=float, default=0.45,
                   help="YOLO IoU NMS threshold (default: 0.45)")
    p.add_argument("--no-homography", action="store_true",
                   help="Disable ORB homography fallback in alignment")
    p.add_argument("--no-save-frames", action="store_true",
                   help="Do not save individual before/after frames (saves disk space)")
    p.add_argument("--no-save-diff", action="store_true",
                   help="Do not save diff visualisation frames")
    p.add_argument("--ecc-iterations", type=int, default=1000,
                   help="ECC max iterations for alignment (default: 1000)")

    return p.parse_args()


def validate_paths(args):
    errors = []
    for attr, label in [
        ("before_video", "Before video"),
        ("after_video", "After video"),
        ("before_gps", "Before GPS CSV"),
        ("after_gps", "After GPS CSV"),
        ("model", "YOLOv8 model"),
    ]:
        val = getattr(args, attr, None)
        if val and not Path(val).exists():
            errors.append(f"{label} not found: {val}")
    return errors


def main():
    args = parse_args()

    # Normalise dashes to underscores for attribute access
    args.before_video = args.before_video
    args.after_video = args.after_video
    args.before_gps = args.before_gps
    args.after_gps = args.after_gps

    errors = validate_paths(args)
    if errors:
        for e in errors:
            logger.error(e)
        sys.exit(1)

    config = DetectionConfig(
        before_video=args.before_video,
        after_video=args.after_video,
        before_gps_csv=args.before_gps,
        after_gps_csv=args.after_gps,
        model_path=args.model,
        output_dir=args.output,
        gps_tolerance_m=args.gps_tolerance,
        use_homography=not args.no_homography,
        ecc_iterations=args.ecc_iterations,
        pixel_diff_threshold=args.pixel_diff,
        min_change_pct=args.min_change_pct,
        change_score_threshold=args.change_threshold,
        yolo_conf=args.yolo_conf,
        yolo_iou=args.yolo_iou,
        save_frames=not args.no_save_frames,
        save_diff_frames=not args.no_save_diff,
    )

    detector = DroneChangeDetector(config)
    events = detector.run()

    print(f"\n{'='*55}")
    print(f"  ✓ Complete. {len(events)} change events detected.")
    print(f"  Output directory: {args.output}/")
    print(f"  Reports: {args.output}/reports/change_report.html")
    print(f"  JSON:    {args.output}/detections/change_events.json")
    print(f"  CSV:     {args.output}/detections/change_events.csv")
    print(f"{'='*55}\n")


if __name__ == "__main__":
    main()
# python main.py --before-video before.mp4  --after-video after.mp4 --before-gps   before.csv  --after-gps  after.csv

# (& c:\Learn\UNIVERSITY_PROJECT\TrackObject\.venv\Scripts\Activate.ps1)(.venv) PS C:\Learn\UNIVERSITY_PROJECT> 
