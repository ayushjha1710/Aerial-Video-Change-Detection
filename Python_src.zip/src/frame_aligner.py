"""
Frame Aligner
=============
Aligns an 'after' drone frame to a 'before' drone frame to compensate for:
  - Camera shake / vibration
  - Slightly different flight altitude or heading
  - GPS positioning error (residual after GPS matching)

Pipeline:
  1. ECC (Enhanced Correlation Coefficient) for global warp estimation — very
     robust to illumination changes.
  2. If ECC fails (poor texture / fog), fall back to ORB feature matching +
     RANSAC homography.
  3. Apply the combined warp to the after-frame.
"""

import cv2
import numpy as np
import logging

logger = logging.getLogger(__name__)


class FrameAligner:
    """
    Aligns `frame_after` to `frame_before` using ECC + optional homography fallback.

    Parameters
    ----------
    use_homography : bool
        If True, also apply ORB feature matching on top of / as fallback to ECC.
    ecc_iterations : int
        Max iterations for ECC optimisation.
    ecc_eps : float
        Convergence epsilon for ECC.
    """

    def __init__(
        self,
        use_homography: bool = True,
        ecc_iterations: int = 1000,
        ecc_eps: float = 1e-6,
    ):
        self.use_homography = use_homography
        self.ecc_criteria = (
            cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT,
            ecc_iterations,
            ecc_eps,
        )

    # ── public ─────────────────────────────────────────────────────────────
    def align(self, frame_ref: np.ndarray, frame_to_align: np.ndarray) -> tuple[np.ndarray, bool]:
        """
        Align `frame_to_align` onto `frame_ref`.

        Returns
        -------
        (aligned_frame, success_flag)
        """
        gray_ref = self._to_gray(frame_ref)
        gray_src = self._to_gray(frame_to_align)

        h, w = gray_ref.shape

        # ── Stage 1: ECC (affine) ──────────────────────────────────────────
        warp_matrix = np.eye(2, 3, dtype=np.float32)
        ecc_ok = False
        try:
            _, warp_matrix = cv2.findTransformECC(
                gray_ref,
                gray_src,
                warp_matrix,
                cv2.MOTION_AFFINE,
                self.ecc_criteria,
                None,
                5,          # gaussian blur size for gradient computation
            )
            ecc_ok = True
        except cv2.error as e:
            logger.debug(f"ECC failed ({e}), falling back to feature matching")

        if ecc_ok:
            aligned = cv2.warpAffine(
                frame_to_align,
                warp_matrix,
                (w, h),
                flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP,
                borderMode=cv2.BORDER_REFLECT,
            )
            return aligned, True

        # ── Stage 2: ORB + RANSAC Homography fallback ─────────────────────
        if self.use_homography:
            aligned, ok = self._homography_align(gray_ref, gray_src, frame_to_align, w, h)
            if ok:
                return aligned, True

        return frame_to_align, False

    # ── private ────────────────────────────────────────────────────────────
    @staticmethod
    def _to_gray(frame: np.ndarray) -> np.ndarray:
        if len(frame.shape) == 3:
            return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return frame

    @staticmethod
    def _homography_align(
        gray_ref: np.ndarray,
        gray_src: np.ndarray,
        color_src: np.ndarray,
        w: int,
        h: int,
    ) -> tuple[np.ndarray, bool]:
        orb = cv2.ORB_create(nfeatures=3000)
        kp1, des1 = orb.detectAndCompute(gray_ref, None)
        kp2, des2 = orb.detectAndCompute(gray_src, None)

        if des1 is None or des2 is None or len(kp1) < 10 or len(kp2) < 10:
            logger.debug("Not enough ORB keypoints for homography")
            return color_src, False

        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
        matches = bf.knnMatch(des1, des2, k=2)

        # Lowe ratio test
        good = []
        for m_n in matches:
            if len(m_n) == 2:
                m, n = m_n
                if m.distance < 0.75 * n.distance:
                    good.append(m)

        if len(good) < 10:
            logger.debug(f"Only {len(good)} good ORB matches — skipping homography")
            return color_src, False

        pts_ref = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        pts_src = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)

        H, mask = cv2.findHomography(pts_src, pts_ref, cv2.RANSAC, 5.0)
        if H is None:
            return color_src, False

        inliers = int(mask.sum()) if mask is not None else 0
        logger.debug(f"Homography: {inliers}/{len(good)} inliers")

        aligned = cv2.warpPerspective(
            color_src, H, (w, h),
            flags=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_REFLECT,
        )
        return aligned, True
