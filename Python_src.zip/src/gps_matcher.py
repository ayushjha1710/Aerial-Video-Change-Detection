"""
GPS-based frame matcher.
Pairs frames from before/after videos that were shot at the same geographic location.
Uses the Haversine formula for accurate metre-level distance on Earth's surface.
"""

import numpy as np
import pandas as pd
import logging
from scipy.spatial import cKDTree

logger = logging.getLogger(__name__)


def haversine_m(lat1, lon1, lat2, lon2) -> float:
    """Return distance in metres between two GPS points."""
    R = 6_371_000  # Earth radius metres
    phi1, phi2 = np.radians(lat1), np.radians(lat2)
    dphi = np.radians(lat2 - lat1)
    dlam = np.radians(lon2 - lon1)
    a = np.sin(dphi / 2) ** 2 + np.cos(phi1) * np.cos(phi2) * np.sin(dlam / 2) ** 2
    return R * 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))


class GPSMatcher:
    """
    Matches frames from two GPS-tagged drone videos by geographic proximity.

    Strategy:
      1. Convert all GPS coords to a local XY plane (metres) centred on the
         mean position — this lets us use a fast cKDTree.
      2. For each 'after' frame, find the nearest 'before' frame within
         `tolerance_m` metres.
      3. Return the 1-to-1 best matches (each before-frame used at most once).
    """

    def __init__(self, tolerance_m: float = 5.0):
        self.tolerance_m = tolerance_m

    # ── public ─────────────────────────────────────────────────────────────
    def match(self, gps_before: pd.DataFrame, gps_after: pd.DataFrame) -> list[dict]:
        """
        Parameters
        ----------
        gps_before, gps_after : DataFrames with columns
            frame_index | latitude | longitude

        Returns
        -------
        List of dicts:  before_frame, after_frame, latitude, longitude, distance_m
        Sorted by average GPS latitude for convenient sequential processing.
        """
        if gps_before.empty or gps_after.empty:
            return []

        # Project to metres around a common origin
        origin_lat = (gps_before["latitude"].mean() + gps_after["latitude"].mean()) / 2
        origin_lon = (gps_before["longitude"].mean() + gps_after["longitude"].mean()) / 2

        xy_before = self._to_xy(gps_before, origin_lat, origin_lon)
        xy_after = self._to_xy(gps_after, origin_lat, origin_lon)

        # Build KD-tree on before-frame positions
        tree = cKDTree(xy_before)
        dists, idxs = tree.query(xy_after, k=1, workers=-1)

        pairs = []
        used_before = set()

        # Sort after-frames by distance to their nearest before-frame (best first)
        order = np.argsort(dists)
        for a_order_idx in order:
            dist = dists[a_order_idx]
            b_tree_idx = idxs[a_order_idx]

            if dist > self.tolerance_m:
                continue
            if b_tree_idx in used_before:
                continue

            used_before.add(b_tree_idx)
            b_row = gps_before.iloc[b_tree_idx]
            a_row = gps_after.iloc[a_order_idx]

            # Representative GPS: average of the two matched points
            avg_lat = (b_row["latitude"] + a_row["latitude"]) / 2
            avg_lon = (b_row["longitude"] + a_row["longitude"]) / 2

            pairs.append({
                "before_frame": int(b_row["frame_index"]),
                "after_frame": int(a_row["frame_index"]),
                "latitude": round(avg_lat, 7),
                "longitude": round(avg_lon, 7),
                "distance_m": round(dist, 2),
            })

        # Sort by frame order for sequential video access (faster seeking)
        pairs.sort(key=lambda p: p["before_frame"])
        logger.info(f"GPS matching: {len(pairs)} pairs within {self.tolerance_m} m tolerance")
        return pairs

    # ── private ────────────────────────────────────────────────────────────
    @staticmethod
    def _to_xy(df: pd.DataFrame, origin_lat: float, origin_lon: float) -> np.ndarray:
        """
        Convert lat/lon to approximate local XY in metres.
        Valid for small areas (< ~50 km); no projection library needed.
        """
        lat_rad = np.radians(df["latitude"].values)
        origin_lat_rad = np.radians(origin_lat)

        x = np.radians(df["longitude"].values - origin_lon) * 6_371_000 * np.cos(origin_lat_rad)
        y = np.radians(df["latitude"].values - origin_lat) * 6_371_000
        return np.column_stack([x, y])
