from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
import shutil
from pathlib import Path

from change_detector import DetectionConfig, DroneChangeDetector

app = FastAPI()

# Allow frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = Path("uploads")
OUTPUT_DIR = Path("output")

UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)




@app.post("/run")
async def run_detection(

    before_video: UploadFile = File(...),
    after_video: UploadFile = File(...),

    before_csv: UploadFile = File(...),
    after_csv: UploadFile = File(...),

    gps_tolerance: float = Form(5),
    change_threshold: float = Form(0.15),
    pixel_diff: int = Form(30),
    min_change_pct: float = Form(2),

    yolo_conf: float = Form(0.25),
    yolo_iou: float = Form(0.45),

    ecc_iterations: int = Form(1000),

    save_frames: bool = Form(True),
    save_diff: bool = Form(True),
    use_homography: bool = Form(True),

):

    before_video_path = UPLOAD_DIR / before_video.filename
    after_video_path = UPLOAD_DIR / after_video.filename

    before_csv_path = UPLOAD_DIR / before_csv.filename
    after_csv_path = UPLOAD_DIR / after_csv.filename

    with open(before_video_path, "wb") as buffer:
        shutil.copyfileobj(before_video.file, buffer)

    with open(after_video_path, "wb") as buffer:
        shutil.copyfileobj(after_video.file, buffer)

    with open(before_csv_path, "wb") as buffer:
        shutil.copyfileobj(before_csv.file, buffer)

    with open(after_csv_path, "wb") as buffer:
        shutil.copyfileobj(after_csv.file, buffer)

    config = DetectionConfig(

        before_video=str(before_video_path),

        after_video=str(after_video_path),

        before_gps_csv=str(before_csv_path),

        after_gps_csv=str(after_csv_path),

        model_path="yolov8n_trained_by_me.pt",

        output_dir="output",

        gps_tolerance_m=gps_tolerance,

        pixel_diff_threshold=pixel_diff,

        min_change_pct=min_change_pct,

        change_score_threshold=change_threshold,

        yolo_conf=yolo_conf,

        yolo_iou=yolo_iou,

        ecc_iterations=ecc_iterations,

        use_homography=use_homography,

        save_frames=save_frames,

        save_diff_frames=save_diff

    )

    detector = DroneChangeDetector(config)

    events = detector.run()

    return {

    "status":"success",

    "events":len(events),

    "report":"http://127.0.0.1:8000/report",

    "csv":"http://127.0.0.1:8000/report/csv",

    "json":"http://127.0.0.1:8000/report/json"

    }



from fastapi.responses import FileResponse

@app.get("/report")
def report():

    return FileResponse(

        "output/reports/change_report.html",

        media_type="text/html"

    )


@app.get("/report/csv")
def csv():

    return FileResponse(

        "output/detections/change_events.csv",

        filename="change_events.csv"

    )


@app.get("/report/json")
def json_report():

    return FileResponse(

        "output/detections/change_events.json",

        filename="change_events.json"

    )

# run using: uvicorn app:app --reload        