"""
Change Analyzer
===============
Computes the degree of change between two aligned drone frames and extracts
changed regions that YOLO did NOT detect (new buildings, tents, debris, etc.).
"""

import cv2
import numpy as np
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class UnknownRegion:
    """A changed region in the after-frame that YOLO did not label."""
    region_id: int
    bbox: list               # [x1, y1, x2, y2] in after-frame pixel coords
    area_px: int             # bounding-box pixel area
    change_intensity: float  # mean diff intensity inside the region (0-1)
    crop_before_path: str = ""
    crop_after_path: str = ""


class ChangeAnalyzer:
    """
    Parameters
    ----------
    pixel_threshold     : per-pixel abs-diff (0-255) to count as changed
    min_change_pct      : minimum % of changed pixels for a real event
    blur_ksize          : gaussian blur kernel (must be odd)
    min_unknown_area    : min bbox area (px²) to save an unknown crop
    yolo_overlap_thresh : IoU above which YOLO "explains" a contour
    crop_padding        : padding pixels around each saved crop
    """

    def __init__(
        self,
        pixel_threshold: int = 30,
        min_change_pct: float = 2.0,
        blur_ksize: int = 5,
        min_unknown_area: int = 500,
        yolo_overlap_thresh: float = 0.3,
        crop_padding: int = 20,
    ):
        self.pixel_threshold = pixel_threshold
        self.min_change_pct = min_change_pct
        self.blur_ksize = blur_ksize if blur_ksize % 2 == 1 else blur_ksize + 1
        self.min_unknown_area = min_unknown_area
        self.yolo_overlap_thresh = yolo_overlap_thresh
        self.crop_padding = crop_padding

    # ───────────────────────────────────────────────────────────────────────
    # Public API
    # ───────────────────────────────────────────────────────────────────────

    def analyze(self, frame_before: np.ndarray, frame_after: np.ndarray) -> tuple:
        """
        Compare two aligned frames.

        Returns  (5 values)
        -------
        change_score     : float  0-1   composite change magnitude
        pixel_change_pct : float  0-100 percentage of pixels that changed
        diff_vis         : ndarray BGR side-by-side visualisation panel
        change_mask      : ndarray uint8 binary mask (255 = changed pixel)
        diff_gray        : ndarray raw grayscale absolute difference image
        """
        gray_b = self._gray_blur(frame_before)
        gray_a = self._gray_blur(frame_after)

        diff_gray = cv2.absdiff(gray_b, gray_a)

        _, mask_raw = cv2.threshold(
            diff_gray, self.pixel_threshold, 255, cv2.THRESH_BINARY
        )
        change_mask = self._clean_mask(mask_raw)

        total_px   = change_mask.size
        changed_px = int(np.count_nonzero(change_mask))
        pixel_change_pct = (changed_px / total_px) * 100.0

        mean_intensity = (
            float(diff_gray[change_mask > 0].mean()) / 255.0
            if changed_px > 0 else 0.0
        )

        area_score   = min(pixel_change_pct / 100.0, 1.0)
        change_score = 0.6 * area_score + 0.4 * mean_intensity

        diff_vis = self._make_visualisation(frame_before, frame_after, change_mask, diff_gray)

        return change_score, pixel_change_pct, diff_vis, change_mask, diff_gray

    def extract_unknown_regions(
        self,
        frame_before: np.ndarray,
        frame_after: np.ndarray,
        change_mask: np.ndarray,
        yolo_detections_after: list,
        diff_gray: np.ndarray = None,
    ) -> list:
        """
        Find changed contours that are NOT covered by any YOLO detection.
        These represent structures the model has no class for:
        tents, new buildings, debris, construction, parked equipment, etc.

        Parameters
        ----------
        frame_before, frame_after   : aligned BGR frames
        change_mask                 : binary mask returned by analyze()
        yolo_detections_after       : list of dicts {"bbox": [x1,y1,x2,y2], ...}
        diff_gray                   : raw diff from analyze(); recomputed if None

        Returns
        -------
        list[UnknownRegion]  — crop paths are empty strings; caller fills them
        """
        if diff_gray is None:
            gray_b    = self._gray_blur(frame_before)
            gray_a    = self._gray_blur(frame_after)
            diff_gray = cv2.absdiff(gray_b, gray_a)

        contours, _ = cv2.findContours(
            change_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        yolo_boxes = [d["bbox"] for d in yolo_detections_after]

        unknown_regions = []
        region_id = 0

        for cnt in contours:
            cx, cy, cw, ch = cv2.boundingRect(cnt)
            bbox_area = cw * ch

            if bbox_area < self.min_unknown_area:
                continue   # too small — noise

            contour_box = [cx, cy, cx + cw, cy + ch]

            # Skip if any YOLO box already covers this region
            if self._is_covered_by_yolo(contour_box, yolo_boxes):
                continue

            roi       = diff_gray[cy: cy + ch, cx: cx + cw]
            intensity = float(roi.mean()) / 255.0 if roi.size > 0 else 0.0

            unknown_regions.append(UnknownRegion(
                region_id=region_id,
                bbox=contour_box,
                area_px=bbox_area,
                change_intensity=round(intensity, 4),
            ))
            region_id += 1

        logger.info(
            f"  Unknown (non-YOLO) regions: {len(unknown_regions)} found  "
            f"[{len(contours)} total contours, {len(yolo_boxes)} YOLO detections excluded]"
        )
        return unknown_regions

    # ───────────────────────────────────────────────────────────────────────
    # Private helpers  — each defined exactly ONCE
    # ───────────────────────────────────────────────────────────────────────

    def _gray_blur(self, frame: np.ndarray) -> np.ndarray:
        """Convert to grayscale (if needed) and apply Gaussian blur."""
        gray = (
            cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            if len(frame.shape) == 3 else frame.copy()
        )
        return cv2.GaussianBlur(gray, (self.blur_ksize, self.blur_ksize), 0)

    @staticmethod
    def _clean_mask(mask: np.ndarray) -> np.ndarray:
        """Morphological open (remove speckles) then close (fill gaps)."""
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask   = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  kernel, iterations=2)
        mask   = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        return mask

    @staticmethod
    def _iou(a: list, b: list) -> float:
        """Intersection-over-Union of two [x1,y1,x2,y2] boxes."""
        ix1 = max(a[0], b[0]);  iy1 = max(a[1], b[1])
        ix2 = min(a[2], b[2]);  iy2 = min(a[3], b[3])
        inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
        if inter == 0:
            return 0.0
        area_a = (a[2] - a[0]) * (a[3] - a[1])
        area_b = (b[2] - b[0]) * (b[3] - b[1])
        return inter / (area_a + area_b - inter + 1e-6)

    def _is_covered_by_yolo(self, contour_box: list, yolo_boxes: list) -> bool:
        """Return True if any YOLO box overlaps the contour above the IoU threshold."""
        return any(
            self._iou(contour_box, ybox) >= self.yolo_overlap_thresh
            for ybox in yolo_boxes
        )

    @staticmethod
    def _make_visualisation(
        before: np.ndarray,
        after: np.ndarray,
        mask: np.ndarray,
        diff_gray: np.ndarray,
    ) -> np.ndarray:
        """Return a 3-panel BGR image: BEFORE | DIFF heatmap | AFTER."""
        contours, _ = cv2.findContours(
            mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        vis_b = before.copy()
        vis_a = after.copy()
        cv2.drawContours(vis_b, contours, -1, (0, 0, 255), 2)
        cv2.drawContours(vis_a, contours, -1, (0, 0, 255), 2)

        diff_norm = cv2.normalize(diff_gray, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        heatmap   = cv2.applyColorMap(diff_norm, cv2.COLORMAP_JET)

        def label(img, text):
            out = img.copy()
            cv2.putText(
                out, text, (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2, cv2.LINE_AA,
            )
            return out

        return np.hstack([
            label(vis_b,   "BEFORE"),
            label(heatmap, "DIFF"),
            label(vis_a,   "AFTER"),
        ])
