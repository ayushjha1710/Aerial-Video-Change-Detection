"""
Report Generator
================
Produces a standalone HTML report summarising all detected change events,
with embedded side-by-side frame comparisons and a GPS summary table.
"""

import base64
import json
import logging
from pathlib import Path
from dataclasses import asdict

logger = logging.getLogger(__name__)


def _b64_img(path: str) -> str:
    """Read an image file and return a base64 data-URI string."""
    p = Path(path)
    if not p.exists():
        return ""
    with open(p, "rb") as f:
        data = base64.b64encode(f.read()).decode()
    ext = p.suffix.lower().lstrip(".")
    mime = "jpeg" if ext in ("jpg", "jpeg") else ext
    return f"data:image/{mime};base64,{data}"


class ReportGenerator:
    def __init__(self, output_dir: Path):
        self.output_dir = output_dir

    def generate(self, events) -> Path:
        report_path = self.output_dir / "reports" / "change_report.html"
        html = self._build_html(events)
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(html)
        logger.info(f"HTML report → {report_path}")
        return report_path

    # ── HTML builder ────────────────────────────────────────────────────────
    def _build_html(self, events) -> str:
        summary_rows = ""
        event_cards = ""

        for i, ev in enumerate(events, 1):
            badge_color = {
                "structural+object": "#e74c3c",
                "object": "#e67e22",
                "structural": "#2980b9",
                "minor": "#27ae60",
            }.get(ev.change_type, "#95a5a6")

            summary_rows += f"""
            <tr>
              <td>{i}</td>
              <td>{ev.gps_lat:.6f}</td>
              <td>{ev.gps_lon:.6f}</td>
              <td>{ev.change_score:.3f}</td>
              <td>{ev.pixel_change_pct:.1f}%</td>
              <td><span class="badge" style="background:{badge_color}">{ev.change_type}</span></td>
              <td><a href="#event-{i}">View ↓</a></td>
            </tr>"""

            new_obj_str = ", ".join(o["class"] for o in ev.new_objects) or "—"
            rem_obj_str = ", ".join(o["class"] for o in ev.removed_objects) or "—"

            img_before = _b64_img(ev.before_frame_path)
            img_diff = _b64_img(ev.diff_frame_path)
            img_after = _b64_img(ev.after_frame_path)

            def img_tag(src, alt):
                if src:
                    return f'<img src="{src}" alt="{alt}" class="frame-img">'
                return f'<div class="no-img">{alt} not available</div>'

            event_cards += f"""
            <div class="card" id="event-{i}">
              <div class="card-header" style="border-left:4px solid {badge_color}">
                <h3>Event #{i} — <span style="color:{badge_color}">{ev.change_type}</span></h3>
                <div class="meta">
                  GPS: {ev.gps_lat:.6f}, {ev.gps_lon:.6f} &nbsp;|&nbsp;
                  Score: <strong>{ev.change_score:.3f}</strong> &nbsp;|&nbsp;
                  Pixel Δ: <strong>{ev.pixel_change_pct:.1f}%</strong>
                </div>
                <div class="meta">
                  Before frame: {ev.before_frame_idx} &nbsp;|&nbsp;
                  After frame: {ev.after_frame_idx}
                </div>
                <div class="meta">
                  New objects: <strong>{new_obj_str}</strong> &nbsp;|&nbsp;
                  Removed: <strong>{rem_obj_str}</strong>
                </div>
              </div>
              <div class="frames">
                <div class="frame-col">
                  <p class="frame-label">BEFORE</p>
                  {img_tag(img_before, "Before")}
                </div>
                <div class="frame-col">
                  <p class="frame-label">DIFF HEATMAP</p>
                  {img_tag(img_diff, "Diff")}
                </div>
                <div class="frame-col">
                  <p class="frame-label">AFTER</p>
                  {img_tag(img_after, "After")}
                </div>
              </div>
            </div>"""

        total_events = len(events)
        type_counts = {}
        for ev in events:
            type_counts[ev.change_type] = type_counts.get(ev.change_type, 0) + 1
        type_summary = " &nbsp;|&nbsp; ".join(
            f"{k}: <strong>{v}</strong>" for k, v in type_counts.items()
        )

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Drone Change Detection Report</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: #f0f2f5; color: #333; }}
    header {{ background: #1a1a2e; color: white; padding: 24px 32px; }}
    header h1 {{ font-size: 1.6rem; }}
    header p {{ opacity: 0.7; margin-top: 4px; font-size: 0.9rem; }}
    .container {{ max-width: 1400px; margin: 0 auto; padding: 24px; }}
    .stats-bar {{ display: flex; gap: 16px; margin-bottom: 24px; flex-wrap: wrap; }}
    .stat-box {{ background: white; border-radius: 8px; padding: 16px 24px;
                 flex: 1; min-width: 160px; box-shadow: 0 1px 4px rgba(0,0,0,.1); }}
    .stat-box .val {{ font-size: 2rem; font-weight: 700; color: #2980b9; }}
    .stat-box .lbl {{ font-size: 0.8rem; color: #888; margin-top: 4px; }}
    table {{ width: 100%; border-collapse: collapse; background: white;
             border-radius: 8px; overflow: hidden;
             box-shadow: 0 1px 4px rgba(0,0,0,.1); margin-bottom: 32px; }}
    th {{ background: #2c3e50; color: white; padding: 12px 16px; text-align: left;
          font-size: 0.85rem; }}
    td {{ padding: 10px 16px; border-bottom: 1px solid #eee; font-size: 0.88rem; }}
    tr:hover td {{ background: #f8f9fa; }}
    .badge {{ display: inline-block; padding: 3px 10px; border-radius: 12px;
              color: white; font-size: 0.78rem; font-weight: 600; }}
    .card {{ background: white; border-radius: 10px; margin-bottom: 24px;
             box-shadow: 0 1px 6px rgba(0,0,0,.12); overflow: hidden; }}
    .card-header {{ padding: 16px 20px; background: #fafbfc; border-bottom: 1px solid #eee; }}
    .card-header h3 {{ margin-bottom: 6px; }}
    .meta {{ font-size: 0.85rem; color: #555; margin-top: 4px; }}
    .frames {{ display: flex; gap: 12px; padding: 16px; flex-wrap: wrap; }}
    .frame-col {{ flex: 1; min-width: 260px; }}
    .frame-label {{ font-size: 0.75rem; font-weight: 700; color: #888;
                    text-align: center; margin-bottom: 6px; letter-spacing: 1px; }}
    .frame-img {{ width: 100%; border-radius: 6px; border: 1px solid #ddd; }}
    .no-img {{ background: #f0f0f0; border-radius: 6px; height: 180px;
               display: flex; align-items: center; justify-content: center;
               color: #aaa; font-size: 0.85rem; }}
    a {{ color: #2980b9; text-decoration: none; }}
    a:hover {{ text-decoration: underline; }}
    h2 {{ margin-bottom: 14px; font-size: 1.1rem; color: #444; }}
  </style>
</head>
<body>
  <header>
    <h1>Change Detection Report</h1>
    <p>GPS-aligned frame comparison using YOLOv8 object detection</p>
  </header>
  <div class="container">
    <div class="stats-bar">
      <div class="stat-box"><div class="val">{total_events}</div>
        <div class="lbl">Change Events</div></div>
      <div class="stat-box"><div class="val" style="font-size:1rem;margin-top:8px">{type_summary}</div>
        <div class="lbl">By Type</div></div>
    </div>

    <h2>Summary Table</h2>
    <table>
      <thead><tr>
        <th>#</th><th>Latitude</th><th>Longitude</th>
        <th>Score</th><th>Pixel Δ</th><th>Type</th><th>Detail</th>
      </tr></thead>
      <tbody>{summary_rows}</tbody>
    </table>

    <h2>Detailed Change Events</h2>
    {event_cards if event_cards else '<p style="color:#888">No change events detected above threshold.</p>'}
  </div>
</body>
</html>"""
