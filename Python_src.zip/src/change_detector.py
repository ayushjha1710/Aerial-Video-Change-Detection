"""
Drone Change Detection System
Detects changes between two drone videos using GPS-based frame alignment,
YOLOv8 object detection, and image-level difference analysis.
"""

import cv2
import numpy as np
import pandas as pd
import torch
import json
import logging
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional
from ultralytics import YOLO

from utils.gps_matcher import GPSMatcher
from utils.frame_aligner import FrameAligner
from utils.change_analyzer import ChangeAnalyzer, UnknownRegion
from utils.report_generator import ReportGenerator

# ─────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Data Structures
# ─────────────────────────────────────────────
@dataclass
class ChangeEvent:
    gps_lat: float
    gps_lon: float
    before_frame_idx: int
    after_frame_idx: int
    change_score: float
    pixel_change_pct: float
    objects_before: list = field(default_factory=list)
    objects_after: list = field(default_factory=list)
    new_objects: list = field(default_factory=list)
    removed_objects: list = field(default_factory=list)
    change_type: str = "unknown"
    before_frame_path: str = ""
    after_frame_path: str = ""
    diff_frame_path: str = ""
    unknown_regions: list = field(default_factory=list)   # YOLO-blind change crops


@dataclass
class DetectionConfig:
    # Paths
    before_video: str = ""
    after_video: str = ""
    before_gps_csv: str = ""
    after_gps_csv: str = ""
    model_path: str = "yolov8n_trained_by_me.pt"
    output_dir: str = "output"

    # GPS matching
    gps_tolerance_m: float = 5.0

    # Alignment
    use_homography: bool = True
    ecc_iterations: int = 1000
    ecc_eps: float = 1e-6

    # Change thresholds
    pixel_diff_threshold: int = 30
    min_change_pct: float = 2.0
    change_score_threshold: float = 0.15

    # YOLO
    yolo_conf: float = 0.25
    yolo_iou: float = 0.45
    device: str = "cuda" if torch.cuda.is_available() else "cpu"

    # Output
    save_frames: bool = True
    save_diff_frames: bool = True

    # Unknown region cropping
    min_unknown_area: int = 500          # min bbox area (px²) to save a crop
    yolo_overlap_thresh: float = 0.3     # IoU above which YOLO "explains" a region
    crop_padding: int = 20               # padding pixels around each crop


# ─────────────────────────────────────────────
# Core Pipeline
# ─────────────────────────────────────────────
class DroneChangeDetector:
    def __init__(self, config: DetectionConfig):
        self.cfg = config
        self.output_dir = Path(config.output_dir)
        self._init_dirs()

        logger.info(f"Loading YOLOv8 model from: {config.model_path}")
        logger.info(f"Running on device: {config.device}")
        self.model = YOLO(config.model_path)
        self.model.to(config.device)

        self.gps_matcher = GPSMatcher(tolerance_m=config.gps_tolerance_m)
        self.aligner = FrameAligner(
            use_homography=config.use_homography,
            ecc_iterations=config.ecc_iterations,
            ecc_eps=config.ecc_eps,
        )
        self.analyzer = ChangeAnalyzer(
            pixel_threshold=config.pixel_diff_threshold,
            min_change_pct=config.min_change_pct,
            min_unknown_area=config.min_unknown_area,
            yolo_overlap_thresh=config.yolo_overlap_thresh,
            crop_padding=config.crop_padding,
        )

    # ── setup ────────────────────────────────
    def _init_dirs(self):
        for sub in [
            "frames/before",
            "frames/after",
            "frames/diff",
            "frames/unknown_crops",
            "detections",
            "reports",
        ]:
            (self.output_dir / sub).mkdir(parents=True, exist_ok=True)

    # ── GPS + video helpers ──────────────────
    def _load_gps(self, csv_path: str) -> pd.DataFrame:
        df = pd.read_csv(csv_path)
        df.columns = [c.strip().lower() for c in df.columns]
        required = {"frame_index", "latitude", "longitude"}
        if not required.issubset(df.columns):
            raise ValueError(
                f"GPS CSV must contain columns: {required}. Got: {set(df.columns)}"
            )
        df = df.sort_values("frame_index").reset_index(drop=True)
        logger.info(f"Loaded {len(df)} GPS entries from {csv_path}")
        return df

    def _extract_frame(self, cap: cv2.VideoCapture, frame_idx: int) -> Optional[np.ndarray]:
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        ret, frame = cap.read()
        return frame if ret else None

    # ── YOLO ────────────────────────────────
    def _run_yolo(self, frame: np.ndarray) -> list:
        results = self.model(
            frame,
            conf=self.cfg.yolo_conf,
            iou=self.cfg.yolo_iou,
            device=self.cfg.device,
            verbose=False,
        )
        detections = []
        for r in results:
            for box in r.boxes:
                detections.append({
                    "class": self.model.names[int(box.cls)],
                    "confidence": round(float(box.conf), 3),
                    "bbox": [round(float(x), 1) for x in box.xyxy[0].tolist()],
                })
        return detections

    # ── frame I/O ────────────────────────────
    def _save_frame(self, frame: np.ndarray, subdir: str, name: str) -> str:
        path = self.output_dir / "frames" / subdir / name
        cv2.imwrite(str(path), frame)
        return str(path)

    def _save_diff(self, diff: np.ndarray, name: str) -> str:
        path = self.output_dir / "frames" / "diff" / name
        cv2.imwrite(str(path), diff)
        return str(path)

    def _save_unknown_crop(
        self,
        frame_before: np.ndarray,
        frame_after: np.ndarray,
        region: UnknownRegion,
        event_tag: str,
        padding: int = 20,
    ):
        """
        Save a padded before/after crop pair for an unknown change region into
        output/frames/unknown_crops/.  Updates region paths in-place.
        """
        h, w = frame_after.shape[:2]
        x1, y1, x2, y2 = region.bbox

        x1p = max(0, x1 - padding)
        y1p = max(0, y1 - padding)
        x2p = min(w, x2 + padding)
        y2p = min(h, y2 + padding)

        crop_b = frame_before[y1p:y2p, x1p:x2p]
        crop_a = frame_after[y1p:y2p, x1p:x2p]

        base   = self.output_dir / "frames" / "unknown_crops"
        name_b = f"{event_tag}_unk{region.region_id}_before.jpg"
        name_a = f"{event_tag}_unk{region.region_id}_after.jpg"

        cv2.imwrite(str(base / name_b), crop_b)
        cv2.imwrite(str(base / name_a), crop_a)

        region.crop_before_path = str(base / name_b)
        region.crop_after_path  = str(base / name_a)

        logger.debug(
            f"    Unknown crop #{region.region_id}: "
            f"area={region.area_px}px² intensity={region.change_intensity:.3f}"
        )

    # ── main pipeline ────────────────────────
    def run(self) -> list:
        cfg = self.cfg

        gps_before = self._load_gps(cfg.before_gps_csv)
        gps_after  = self._load_gps(cfg.after_gps_csv)

        logger.info("Matching GPS coordinates between videos …")
        pairs = self.gps_matcher.match(gps_before, gps_after)
        logger.info(f"Found {len(pairs)} matching GPS pairs")

        if not pairs:
            logger.warning("No GPS matches found. Check --gps-tolerance or CSV data.")
            return []

        cap_before = cv2.VideoCapture(cfg.before_video)
        cap_after  = cv2.VideoCapture(cfg.after_video)

        if not cap_before.isOpened():
            raise IOError(f"Cannot open before-video: {cfg.before_video}")
        if not cap_after.isOpened():
            raise IOError(f"Cannot open after-video: {cfg.after_video}")

        change_events = []

        for i, pair in enumerate(pairs):
            b_idx = int(pair["before_frame"])
            a_idx = int(pair["after_frame"])
            lat   = pair["latitude"]
            lon   = pair["longitude"]

            logger.info(
                f"[{i+1}/{len(pairs)}] GPS ({lat:.6f}, {lon:.6f}) | "
                f"Before frame {b_idx} ↔ After frame {a_idx}"
            )

            frame_b = self._extract_frame(cap_before, b_idx)
            frame_a = self._extract_frame(cap_after,  a_idx)

            if frame_b is None or frame_a is None:
                logger.warning("  Could not read frames — skipping pair")
                continue

            if frame_b.shape != frame_a.shape:
                frame_a = cv2.resize(frame_a, (frame_b.shape[1], frame_b.shape[0]))

            frame_a_aligned, alignment_ok = self.aligner.align(frame_b, frame_a)
            if not alignment_ok:
                logger.warning("  Alignment failed — using raw frame")
                frame_a_aligned = frame_a

            # ── 1. Pixel-level change analysis ──────────────────────────
            # analyze() returns 5 values; diff_gray is passed on to avoid
            # recomputing it inside extract_unknown_regions.
            change_score, pixel_pct, diff_vis, change_mask, diff_gray = \
                self.analyzer.analyze(frame_b, frame_a_aligned)

            if change_score < cfg.change_score_threshold:
                logger.info(f"  Change score {change_score:.3f} below threshold — skipping")
                continue

            logger.info(
                f"  ✓ Change detected! score={change_score:.3f}  pixel_pct={pixel_pct:.1f}%"
            )

            # ── 2. YOLO detections ───────────────────────────────────────
            dets_before = self._run_yolo(frame_b)
            dets_after  = self._run_yolo(frame_a_aligned)

            new_objs, removed_objs = self._diff_detections(dets_before, dets_after)
            change_type = self._classify_change(pixel_pct, new_objs, removed_objs)

            # ── 3. Unknown region extraction ─────────────────────────────
            # Finds changed contours NOT covered by any YOLO detection:
            # new buildings, tents, rubble, construction, etc.
            unknown_regions = self.analyzer.extract_unknown_regions(
                frame_before=frame_b,
                frame_after=frame_a_aligned,
                change_mask=change_mask,
                yolo_detections_after=dets_after,
                diff_gray=diff_gray,           # reuse — no recompute needed
            )

            # ── 4. Save frames & crops ───────────────────────────────────
            tag = f"lat{lat:.5f}_lon{lon:.5f}_b{b_idx}_a{a_idx}"

            if cfg.save_frames:
                for reg in unknown_regions:
                    self._save_unknown_crop(
                        frame_b, frame_a_aligned, reg, tag,
                        padding=cfg.crop_padding,
                    )

            bf_path = aa_path = df_path = ""
            if cfg.save_frames:
                bf_path = self._save_frame(frame_b,          "before", f"{tag}.jpg")
                aa_path = self._save_frame(frame_a_aligned,  "after",  f"{tag}.jpg")
            if cfg.save_diff_frames:
                df_path = self._save_diff(diff_vis, f"{tag}_diff.jpg")

            event = ChangeEvent(
                gps_lat=lat,
                gps_lon=lon,
                before_frame_idx=b_idx,
                after_frame_idx=a_idx,
                change_score=round(change_score, 4),
                pixel_change_pct=round(pixel_pct, 2),
                objects_before=dets_before,
                objects_after=dets_after,
                new_objects=new_objs,
                removed_objects=removed_objs,
                change_type=change_type,
                before_frame_path=bf_path,
                after_frame_path=aa_path,
                diff_frame_path=df_path,
                unknown_regions=[asdict(r) for r in unknown_regions],
            )
            change_events.append(event)

        cap_before.release()
        cap_after.release()

        self._save_json(change_events)
        self._save_csv(change_events)

        reporter = ReportGenerator(self.output_dir)
        reporter.generate(change_events)

        logger.info(f"\n{'='*50}")
        logger.info(f"Detection complete. {len(change_events)} change events found.")
        logger.info(f"Results saved to: {self.output_dir}/")
        return change_events

    # ── static helpers ───────────────────────
    @staticmethod
    def _diff_detections(before: list, after: list) -> tuple:
        cls_before = [d["class"] for d in before]
        cls_after  = [d["class"] for d in after]
        new_objects     = [d for d in after  if d["class"] not in cls_before]
        removed_objects = [d for d in before if d["class"] not in cls_after]
        return new_objects, removed_objects
    
   

    @staticmethod
    def _classify_change(pixel_pct: float, new_objs: list, removed_objs: list) -> str:
        has_pixel  = pixel_pct > 5.0
        has_object = bool(new_objs or removed_objs)
        if has_pixel and has_object:
            return "structural+object"
        if has_object:
            return "object"
        if has_pixel:
            return "structural"
        return "minor"

    def _save_json(self, events: list):
        path = self.output_dir / "detections" / "change_events.json"
        with open(path, "w") as f:
            json.dump([asdict(e) for e in events], f, indent=2)
        logger.info(f"JSON results → {path}")

    def _save_csv(self, events: list):
        if not events:
            return
        rows = []
        for e in events:
            rows.append({
                "latitude":             e.gps_lat,
                "longitude":            e.gps_lon,
                "before_frame":         e.before_frame_idx,
                "after_frame":          e.after_frame_idx,
                "change_score":         e.change_score,
                "pixel_change_pct":     e.pixel_change_pct,
                "change_type":          e.change_type,
                "new_objects":          ", ".join(o["class"] for o in e.new_objects),
                "removed_objects":      ", ".join(o["class"] for o in e.removed_objects),
                "unknown_region_count": len(e.unknown_regions),
                "before_frame_path":    e.before_frame_path,
                "after_frame_path":     e.after_frame_path,
                "diff_frame_path":      e.diff_frame_path,
            })
        df   = pd.DataFrame(rows)
        path = self.output_dir / "detections" / "change_events.csv"
        df.to_csv(path, index=False)
        logger.info(f"CSV results → {path}")
