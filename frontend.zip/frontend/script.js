const form=document.getElementById("uploadForm");

form.addEventListener("submit",function(e){

    e.preventDefault();

    document.getElementById("progressSection").classList.remove("hidden");

    let formData=new FormData();

    formData.append("before_video",
        document.getElementById("beforeVideo").files[0]);

    formData.append("after_video",
        document.getElementById("afterVideo").files[0]);

    formData.append("before_csv",
        document.getElementById("beforeCSV").files[0]);

    formData.append("after_csv",
        document.getElementById("afterCSV").files[0]);

    formData.append("gps_tolerance",
        document.getElementById("gps").value);

    formData.append("change_threshold",
        document.getElementById("change").value);

    formData.append("pixel_diff",
        document.getElementById("pixel").value);

    formData.append("min_change_pct",
        document.getElementById("minChange").value);

    formData.append("yolo_conf",
        document.getElementById("conf").value);

    formData.append("yolo_iou",
        document.getElementById("iou").value);

    formData.append("ecc_iterations",
        document.getElementById("ecc").value);

    formData.append("save_frames",
        document.getElementById("frames").checked);

    formData.append("save_diff",
        document.getElementById("diff").checked);

    formData.append("use_homography",
        document.getElementById("homography").checked);


    fetch("http://127.0.0.1:8000/run",{

        method:"POST",

        body:formData

    })

    .then(res=>res.json())

    .then(data=>{

    clearInterval(loadingInterval);

    document.getElementById("progressSection").style.display="none";

    document.getElementById("resultSection").style.display="block";

    document.getElementById("status").innerHTML=
    "✔ Analysis Completed Successfully";

    document.getElementById("resultSection").style.display="block";

    document.getElementById("eventCount").innerHTML=data.events;

    document.getElementById("viewReport").href=data.report;

    document.getElementById("downloadCSV").href=data.csv;

    document.getElementById("downloadJSON").href=data.json;

})

    .catch(err=>{

    clearInterval(loadingInterval);

    document.querySelector(".loader").style.display="none";

    document.getElementById("status").innerHTML=
    "Error occurred.";

    console.log(err);

});


    showStatus();

});
let loadingInterval;

function showStatus(){

    const status=document.getElementById("status");

    const messages=[

        "Uploading Files...",
        "Matching GPS Coordinates...",
        "Aligning Frames...",
        "Running YOLO Detection...",
        "Detecting Unknown Regions...",
        "Generating Report..."

    ];

    let i=0;

    loadingInterval = setInterval(()=>{

        status.innerHTML=messages[i];

        i=(i+1)%messages.length;

    },2500);

}
function fakeProgress(){

    let p=0;

    let bar=document.getElementById("progress");

    let status=document.getElementById("status");

    let timer=setInterval(()=>{

        if(p>=95){

            clearInterval(timer);

        }

        p++;

        bar.style.width=p+"%";

        if(p<20)

            status.innerHTML="Uploading Files...";

        else if(p<40)

            status.innerHTML="Matching GPS Coordinates...";

        else if(p<60)

            status.innerHTML="Aligning Frames...";

        else if(p<80)

            status.innerHTML="Running YOLO Detection...";

        else

            status.innerHTML="Generating Report...";

    },300);

}